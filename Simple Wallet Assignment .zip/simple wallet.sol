// SPDX-SPDX-LINCENSE-SPDX-SPDX-LINCENSE-IDENTIFIER: UNLICENSED 
pragma solidity ^0.8.34;

contract SimpleWallet {

// Mapping to store each user's balance
mapping(address => uint256) public balances;

// Deposit function (adds money to sender balances)
function deposit() public payable { balances[msg.sender] += 
msg.value;
 }

//Function to check balance 
function checkBalance() public view returns (uint256) {
    return balances[msg.sender];
 }
}
