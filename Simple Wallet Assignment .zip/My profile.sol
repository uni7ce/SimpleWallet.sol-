//SPDX-License-Identifier: MIT
pragma solidity ^0.8.34;

contract Myprofile { 

// State variables {Store it on blockchain}
string public name;
uint256 public age;
string public favoritelanguage;

//Function to update profile data 
function updateprofile(string memory _name,uint256 _age, string memory _language)
public {name = _name ; age = _age; favoritelanguage = _language;
}

//Function to retrieve profiledata
function getProfiles()public view returns (string memory, uint256, string memory)
 {
    return (name,age,favoritelanguage);
 } 
}